
struct HTMLTemplates
{
  static let index = """

  """

  static let testSummary = """

  """

  static let test = """

  """

  static let activity = """

  """
}

